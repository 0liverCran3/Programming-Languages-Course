concat_lists([],List2,List2).
concat_lists([Head|Elem],) :- 